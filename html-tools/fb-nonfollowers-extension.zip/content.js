// content.js — injected on /following and /followers pages

(function () {
  // Avoid double-injection
  if (window.__fbNFInjected) return;
  window.__fbNFInjected = true;

  const isFollowing = location.pathname.includes('/following');
  const isFollowers = location.pathname.includes('/followers');
  if (!isFollowing && !isFollowers) return;

  const pageType = isFollowing ? 'following' : 'followers';

  // ── Floating UI button ─────────────────────────────────────────────────────
  const btn = document.createElement('div');
  btn.id = '__fbNFBtn';
  btn.innerHTML = `
    <div style="
      position:fixed; bottom:28px; right:28px; z-index:999999;
      background:#1877f2; color:#fff; border-radius:12px;
      padding:12px 20px; font-family:system-ui,sans-serif; font-size:13px;
      font-weight:600; cursor:pointer; box-shadow:0 4px 20px rgba(0,0,0,0.35);
      display:flex; align-items:center; gap:10px; user-select:none;
      transition: background 0.2s;
    " id="__fbNFBtnInner">
      <span style="font-size:18px">🔍</span>
      <span id="__fbNFBtnLabel">Scrape ${pageType === 'following' ? 'Following' : 'Followers'}</span>
    </div>`;
  document.body.appendChild(btn);

  const inner = document.getElementById('__fbNFBtnInner');
  const label = document.getElementById('__fbNFBtnLabel');

  inner.addEventListener('mouseenter', () => inner.style.background = '#145dbf');
  inner.addEventListener('mouseleave', () => inner.style.background = '#1877f2');

  // ── Toast notification ─────────────────────────────────────────────────────
  function toast(msg, color = '#1877f2') {
    const t = document.createElement('div');
    t.style.cssText = `
      position:fixed; bottom:90px; right:28px; z-index:999999;
      background:${color}; color:#fff; border-radius:8px;
      padding:10px 16px; font-family:system-ui,sans-serif; font-size:12px;
      font-weight:500; box-shadow:0 4px 16px rgba(0,0,0,0.3);
      max-width:260px; line-height:1.5;
      animation: fadeIn 0.2s ease;
    `;
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  }

  // ── Auto-scroll to load all profiles ──────────────────────────────────────
  function autoScroll() {
    return new Promise(resolve => {
      label.textContent = 'Scrolling… 0%';
      inner.style.background = '#e8a000';
      let lastHeight = 0;
      let stableCount = 0;

      const interval = setInterval(() => {
        window.scrollTo(0, document.body.scrollHeight);
        const newHeight = document.body.scrollHeight;

        if (newHeight === lastHeight) {
          stableCount++;
          if (stableCount >= 4) {
            clearInterval(interval);
            resolve();
          }
        } else {
          stableCount = 0;
          lastHeight = newHeight;
          const pct = Math.min(99, Math.round((window.scrollY / document.body.scrollHeight) * 100));
          label.textContent = `Scrolling… ${pct}%`;
        }
      }, 800);
    });
  }

  // ── Extract profile links ──────────────────────────────────────────────────
  function extractProfiles() {
    const links = new Set();
    const anchors = document.querySelectorAll('a[href]');

    anchors.forEach(a => {
      const href = a.href || '';
      if (
        href.includes('facebook.com/') &&
        !href.includes('/groups/') &&
        !href.includes('/pages/category/') &&
        !href.includes('/events/') &&
        !href.includes('/hashtag/') &&
        !href.includes('/help/') &&
        !href.includes('/policies/') &&
        !href.includes('/login') &&
        !href.includes('/photo') &&
        !href.includes('/video') &&
        !href.includes('/posts/') &&
        !href.includes('/permalink/') &&
        !href.includes('/following') &&
        !href.includes('/followers') &&
        !href.includes('/marketplace') &&
        !href.includes('/watch') &&
        !href.includes('/gaming') &&
        !href.includes('facebook.com/?') &&
        !href.includes('facebook.com/#')
      ) {
        try {
          const url = new URL(href);
          const parts = url.pathname.replace(/\/$/, '').split('/').filter(Boolean);
          // Only single-segment paths = profile usernames
          if (parts.length === 1 && parts[0].length > 0) {
            const clean = 'https://www.facebook.com/' + parts[0];
            links.add(clean);
          }
        } catch (e) {}
      }
    });

    return [...links];
  }

  // ── Main click handler ─────────────────────────────────────────────────────
  btn.addEventListener('click', async () => {
    btn.style.pointerEvents = 'none';
    toast(`Starting scroll on ${pageType} page…`);

    await autoScroll();

    label.textContent = 'Extracting…';
    inner.style.background = '#1877f2';

    const profiles = extractProfiles();

    if (profiles.length === 0) {
      toast('⚠️ No profiles found. Facebook may have updated their layout.', '#e53e3e');
      label.textContent = `Scrape ${pageType}`;
      btn.style.pointerEvents = 'auto';
      return;
    }

    // Save to chrome.storage
    chrome.storage.local.get(['following', 'followers'], (data) => {
      const update = {};
      update[pageType] = profiles;
      chrome.storage.local.set(update, () => {
        const count = profiles.length;
        label.textContent = `✓ Saved ${count}`;
        inner.style.background = '#2e7d32';
        toast(`✅ ${count} ${pageType} profiles saved!\n${pageType === 'following' ? 'Now go to your /followers page and scrape that too.' : 'Open the extension popup to compare!'}`, '#2e7d32');
        btn.style.pointerEvents = 'auto';

        // Notify popup if open
        chrome.runtime.sendMessage({ type: 'SCRAPED', pageType, count });
      });
    });
  });

})();
