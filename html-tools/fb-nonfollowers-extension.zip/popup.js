// popup.js — Enhanced with visited tracking, open-in-page

const VISITED_KEY = 'fb_nf_visited'; // stored in localStorage (not chrome.storage)

function normalise(url) {
  try {
    const u = new URL(url.trim());
    return (u.origin + u.pathname).replace(/\/$/, '').toLowerCase();
  } catch (e) { return url.trim().toLowerCase(); }
}

// ── Visited helpers ────────────────────────────────────────────────────────
function getVisited() {
  try { return new Set(JSON.parse(localStorage.getItem(VISITED_KEY) || '[]')); }
  catch (e) { return new Set(); }
}
function saveVisited(set) {
  localStorage.setItem(VISITED_KEY, JSON.stringify([...set]));
}
function toggleVisited(url) {
  const v = getVisited();
  const n = normalise(url);
  if (v.has(n)) v.delete(n); else v.add(n);
  saveVisited(v);
  return v;
}

// ── Status panel ───────────────────────────────────────────────────────────
function updateStatus(data) {
  const following = data.following || null;
  const followers = data.followers || null;

  const updateCell = (dot, val, step, num, data, label) => {
    if (data) {
      dot.classList.add('ready');
      val.textContent = data.length;
      step.classList.add('done');
      num.textContent = '✓';
    } else {
      dot.classList.remove('ready');
      val.textContent = '—';
      step.classList.remove('done');
      num.textContent = label;
    }
  };

  updateCell(
    document.getElementById('dotFollowing'), document.getElementById('valFollowing'),
    document.getElementById('step1'), document.getElementById('num1'),
    following, '1'
  );
  updateCell(
    document.getElementById('dotFollowers'), document.getElementById('valFollowers'),
    document.getElementById('step2'), document.getElementById('num2'),
    followers, '2'
  );

  const bothReady = following && followers;
  document.getElementById('compareBtn').disabled = !bothReady;
  if (bothReady) document.getElementById('step3').classList.add('done');
  else document.getElementById('step3').classList.remove('done');
}

// ── Render results ─────────────────────────────────────────────────────────
function renderResults(following, followers) {
  const followersSet = new Set(followers.map(normalise));
  const nonFollowers = following.filter(u => !followersSet.has(normalise(u)));

  document.getElementById('sFollowing').textContent = following.length;
  document.getElementById('sFollowers').textContent = followers.length;
  document.getElementById('sNonFollow').textContent = nonFollowers.length;

  const list = document.getElementById('profileList');
  list.innerHTML = '';

  const visited = getVisited();

  if (nonFollowers.length === 0) {
    list.innerHTML = `<div class="empty"><span class="icon">🎉</span>Everyone follows you back!</div>`;
    document.getElementById('visitedBar').style.display = 'none';
  } else {
    nonFollowers.forEach(url => {
      const isVisited = visited.has(normalise(url));
      const div = document.createElement('div');
      div.className = 'profile-item' + (isVisited ? ' visited' : '');
      div.dataset.url = url;

      const check = document.createElement('div');
      check.className = 'visit-check';
      check.title = isVisited ? 'Mark as not visited' : 'Mark as visited';
      check.textContent = isVisited ? '✓' : '';
      check.addEventListener('click', (e) => {
        e.preventDefault();
        const v = toggleVisited(url);
        const parent = check.closest('.profile-item');
        const nowVisited = v.has(normalise(url));
        parent.classList.toggle('visited', nowVisited);
        check.textContent = nowVisited ? '✓' : '';
        check.title = nowVisited ? 'Mark as not visited' : 'Mark as visited';
        updateVisitedBar(nonFollowers);
      });

      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.textContent = url.replace('https://www.facebook.com/', '');
      a.title = url;
      // Track click as visited
      a.addEventListener('click', () => {
        const v = getVisited();
        v.add(normalise(url));
        saveVisited(v);
        div.classList.add('visited');
        check.textContent = '✓';
        setTimeout(() => updateVisitedBar(nonFollowers), 100);
      });

      div.appendChild(check);
      div.appendChild(a);
      list.appendChild(div);
    });

    document.getElementById('visitedBar').style.display = 'block';
    updateVisitedBar(nonFollowers);
  }

  document.getElementById('listLabel').textContent =
    `${nonFollowers.length} profile${nonFollowers.length !== 1 ? 's' : ''} not following back`;

  document.getElementById('results').style.display = 'block';

  // Show open-page button
  document.getElementById('openPageBtn').style.display = 'inline-block';

  // Copy button
  document.getElementById('copyListBtn').onclick = () => {
    const text = nonFollowers.join('\n');
    navigator.clipboard.writeText(text).then(() => {
      const btn = document.getElementById('copyListBtn');
      btn.textContent = '✓ Copied!';
      setTimeout(() => btn.textContent = 'Copy All', 2000);
    });
  };

  // Open full page button — store data then open results.html
  document.getElementById('openPageBtn').onclick = () => {
    chrome.storage.local.set({ lastResult: { following, followers, nonFollowers } }, () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('results.html') });
    });
  };
}

function updateVisitedBar(nonFollowers) {
  const visited = getVisited();
  const total = nonFollowers.length;
  const count = nonFollowers.filter(u => visited.has(normalise(u))).length;
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  document.getElementById('visitedCount').textContent = `${count} / ${total}`;
  document.getElementById('visitedFill').style.width = pct + '%';
}

// ── Init ───────────────────────────────────────────────────────────────────
chrome.storage.local.get(['following', 'followers'], (data) => {
  updateStatus(data);
  if (data.following && data.followers) {
    renderResults(data.following, data.followers);
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    chrome.storage.local.get(['following', 'followers'], (data) => {
      updateStatus(data);
      if (data.following && data.followers) renderResults(data.following, data.followers);
    });
  }
});

document.getElementById('compareBtn').addEventListener('click', () => {
  chrome.storage.local.get(['following', 'followers'], (data) => {
    if (!data.following || !data.followers) {
      const err = document.getElementById('errorMsg');
      err.textContent = '⚠️ Please scrape both pages first using the 🔍 button.';
      err.style.display = 'block';
      setTimeout(() => err.style.display = 'none', 3000);
      return;
    }
    renderResults(data.following, data.followers);
  });
});

document.getElementById('clearBtn').addEventListener('click', () => {
  if (!confirm('Reset all scraped data? This cannot be undone.')) return;
  chrome.storage.local.remove(['following', 'followers', 'lastResult'], () => {
    chrome.storage.local.get(['following', 'followers'], (data) => {
      updateStatus(data);
      document.getElementById('results').style.display = 'none';
      document.getElementById('openPageBtn').style.display = 'none';
    });
  });
});

function openTab(type) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const current = tabs[0] && tabs[0].url;
    // Try to extract page handle from current fb tab
    let handle = 'me';
    if (current && current.includes('facebook.com/')) {
      const match = current.match(/facebook\.com\/([^/?#]+)/);
      if (match && !['home', 'watch', 'marketplace', 'gaming'].includes(match[1])) {
        handle = match[1];
      }
    }
    chrome.tabs.create({ url: `https://www.facebook.com/${handle}/${type}` });
  });
}
