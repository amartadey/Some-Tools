// results.js — External script for results.html (required by extension CSP)

const VISITED_KEY = 'fb_nf_visited';
let allNonFollowers = [];
let currentFilter = 'all';
let currentSearchQuery = '';

function normalise(url) {
    try {
        const u = new URL(url.trim());
        return (u.origin + u.pathname).replace(/\/$/, '').toLowerCase();
    } catch (e) { return url.trim().toLowerCase(); }
}

function getVisited() {
    try { return new Set(JSON.parse(localStorage.getItem(VISITED_KEY) || '[]')); }
    catch (e) { return new Set(); }
}
function saveVisited(set) {
    localStorage.setItem(VISITED_KEY, JSON.stringify([...set]));
    updateStats();
    updateProgress();
}
function toggleVisited(url) {
    const v = getVisited();
    const n = normalise(url);
    if (v.has(n)) v.delete(n); else v.add(n);
    saveVisited(v);
    return v;
}

function updateStats() {
    const visited = getVisited();
    const visitedCount = allNonFollowers.filter(u => visited.has(normalise(u))).length;
    document.getElementById('statVisited').textContent = visitedCount;
}

function updateProgress() {
    const visited = getVisited();
    const total = allNonFollowers.length;
    const count = allNonFollowers.filter(u => visited.has(normalise(u))).length;
    const pct = total > 0 ? Math.round((count / total) * 100) : 0;
    document.getElementById('progressFill').style.width = pct + '%';
    document.getElementById('progressCount').textContent = `${count} / ${total} (${pct}%)`;
}

function getUsernameFromUrl(url) {
    try {
        return new URL(url).pathname.replace(/^\//, '').replace(/\/$/, '');
    } catch (e) { return url; }
}

function getInitial(url) {
    const u = getUsernameFromUrl(url);
    return u.charAt(0).toUpperCase() || '?';
}

function renderList() {
    const visited = getVisited();
    const query = currentSearchQuery.toLowerCase();

    const filtered = allNonFollowers.filter(url => {
        const matchSearch = !query || url.toLowerCase().includes(query);
        const isVisited = visited.has(normalise(url));
        const matchFilter =
            currentFilter === 'all' ||
            (currentFilter === 'visited' && isVisited) ||
            (currentFilter === 'unvisited' && !isVisited);
        return matchSearch && matchFilter;
    });

    const list = document.getElementById('resultsList');
    list.innerHTML = '';

    if (allNonFollowers.length === 0) {
        list.innerHTML = `
      <div class="empty-state">
        <span class="icon">🎉</span>
        <h2>Everyone follows you back!</h2>
        <p>No non-followers found in your scraped data.</p>
      </div>`;
        return;
    }

    if (filtered.length === 0) {
        list.innerHTML = `
      <div class="empty-state">
        <span class="icon">🔍</span>
        <h2>No results found</h2>
        <p>Try adjusting your search or filter.</p>
      </div>`;
        return;
    }

    filtered.forEach((url) => {
        const isVisited = visited.has(normalise(url));
        const username = getUsernameFromUrl(url);
        const initial = getInitial(url);
        const globalIdx = allNonFollowers.indexOf(url) + 1;

        const item = document.createElement('div');
        item.className = 'result-item' + (isVisited ? ' visited' : '');
        item.dataset.url = url;
        item.innerHTML = `
      <span class="item-num">${globalIdx}</span>
      <div class="item-avatar">${initial}</div>
      <div class="item-info">
        <div class="item-username">@${username}</div>
        <span class="item-url">${url}</span>
      </div>
      <div class="item-actions">
        <a href="${url}" target="_blank" class="visit-btn">Open Profile ↗</a>
        <button class="check-btn" title="${isVisited ? 'Unmark' : 'Mark as checked'}">${isVisited ? '✓' : ''}</button>
      </div>`;

        // Click profile link → auto-mark visited
        item.querySelector('.visit-btn').addEventListener('click', () => {
            const v = getVisited();
            v.add(normalise(url));
            saveVisited(v);
            item.classList.add('visited');
            item.querySelector('.check-btn').textContent = '✓';
        });

        // Toggle check button
        item.querySelector('.check-btn').addEventListener('click', () => {
            const v = toggleVisited(url);
            const nowVisited = v.has(normalise(url));
            item.classList.toggle('visited', nowVisited);
            item.querySelector('.check-btn').textContent = nowVisited ? '✓' : '';
            item.querySelector('.check-btn').title = nowVisited ? 'Unmark' : 'Mark as checked';
            if (currentFilter !== 'all') renderList();
        });

        list.appendChild(item);
    });
}

window.setFilter = function (f, btn) {
    currentFilter = f;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderList();
};

window.markAllVisited = function () {
    const v = getVisited();
    allNonFollowers.forEach(url => v.add(normalise(url)));
    saveVisited(v);
    renderList();
};

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('searchBox').addEventListener('input', (e) => {
        currentSearchQuery = e.target.value;
        renderList();
    });

    document.getElementById('copyAllBtn').addEventListener('click', () => {
        const text = allNonFollowers.join('\n');
        navigator.clipboard.writeText(text).then(() => {
            const btn = document.getElementById('copyAllBtn');
            btn.textContent = '✓ Copied!';
            setTimeout(() => btn.textContent = '📋 Copy All', 2000);
        });
    });

    document.getElementById('exportCsvBtn').addEventListener('click', () => {
        const visited = getVisited();
        const rows = [['#', 'Username', 'Profile URL', 'Checked']];
        allNonFollowers.forEach((url, i) => {
            rows.push([i + 1, getUsernameFromUrl(url), url, visited.has(normalise(url)) ? 'Yes' : 'No']);
        });
        const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
        const blob = new Blob([csv], { type: 'text/csv' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'fb-non-followers.csv';
        a.click();
    });

    document.getElementById('clearVisitedBtn').addEventListener('click', () => {
        if (!confirm('Clear all checked marks?')) return;
        localStorage.removeItem(VISITED_KEY);
        updateStats();
        updateProgress();
        renderList();
    });

    // Load data from chrome.storage
    chrome.storage.local.get(['lastResult'], (data) => {
        const r = data.lastResult;
        if (!r || !r.nonFollowers) {
            document.getElementById('noDataMsg').classList.remove('hidden');
            return;
        }

        allNonFollowers = r.nonFollowers;

        document.getElementById('statFollowing').textContent = r.following.length;
        document.getElementById('statFollowers').textContent = r.followers.length;
        document.getElementById('statNonFollow').textContent = r.nonFollowers.length;
        document.getElementById('pageSubtitle').textContent =
            `${r.nonFollowers.length} profile${r.nonFollowers.length !== 1 ? 's' : ''} not following you back`;

        updateStats();
        updateProgress();
        renderList();
        document.getElementById('mainContent').classList.remove('hidden');
    });
});
