// popup.js

function normalise(url) {
  try {
    const u = new URL(url.trim());
    return (u.origin + u.pathname).replace(/\/$/, '').toLowerCase();
  } catch (e) { return url.trim().toLowerCase(); }
}

function updateStatus(data) {
  const following = data.following || null;
  const followers = data.followers || null;

  const dotF = document.getElementById('dotFollowing');
  const dotFo = document.getElementById('dotFollowers');
  const valF = document.getElementById('valFollowing');
  const valFo = document.getElementById('valFollowers');
  const step1 = document.getElementById('step1');
  const step2 = document.getElementById('step2');
  const step3 = document.getElementById('step3');
  const compareBtn = document.getElementById('compareBtn');

  if (following) {
    dotF.classList.add('ready');
    valF.textContent = following.length;
    step1.classList.add('done');
    document.getElementById('num1').textContent = '✓';
  } else {
    dotF.classList.remove('ready');
    valF.textContent = '—';
    step1.classList.remove('done');
    document.getElementById('num1').textContent = '1';
  }

  if (followers) {
    dotFo.classList.add('ready');
    valFo.textContent = followers.length;
    step2.classList.add('done');
    document.getElementById('num2').textContent = '✓';
  } else {
    dotFo.classList.remove('ready');
    valFo.textContent = '—';
    step2.classList.remove('done');
    document.getElementById('num2').textContent = '2';
  }

  const bothReady = following && followers;
  compareBtn.disabled = !bothReady;
  if (bothReady) step3.classList.add('done');
}

function compare(data) {
  const following = data.following || [];
  const followers = data.followers || [];

  const followersSet = new Set(followers.map(normalise));
  const nonFollowers = following.filter(u => !followersSet.has(normalise(u)));

  document.getElementById('sFollowing').textContent = following.length;
  document.getElementById('sFollowers').textContent = followers.length;
  document.getElementById('sNonFollow').textContent = nonFollowers.length;

  const list = document.getElementById('profileList');
  list.innerHTML = '';

  if (nonFollowers.length === 0) {
    list.innerHTML = `<div class="empty"><span class="icon">🎉</span>Everyone follows you back!</div>`;
  } else {
    nonFollowers.forEach(url => {
      const div = document.createElement('div');
      div.className = 'profile-item';
      const username = url.split('/').pop();
      div.innerHTML = `<a href="${url}" target="_blank">${url}</a>`;
      list.appendChild(div);
    });
  }

  document.getElementById('listLabel').textContent =
    `${nonFollowers.length} PROFILE${nonFollowers.length !== 1 ? 'S' : ''} NOT FOLLOWING YOU BACK`;

  document.getElementById('results').style.display = 'block';

  // Copy list button
  document.getElementById('copyListBtn').onclick = () => {
    const text = nonFollowers.join('\n');
    navigator.clipboard.writeText(text).then(() => {
      const btn = document.getElementById('copyListBtn');
      btn.textContent = '✓ Copied!';
      setTimeout(() => btn.textContent = 'Copy all as list', 2000);
    });
  };
}

// ── Init ───────────────────────────────────────────────────────────────────
chrome.storage.local.get(['following', 'followers'], (data) => {
  updateStatus(data);
  // If both ready, auto-compare
  if (data.following && data.followers) {
    compare(data);
  }
});

// Live updates when content script saves data
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    chrome.storage.local.get(['following', 'followers'], (data) => {
      updateStatus(data);
      if (data.following && data.followers) compare(data);
    });
  }
});

document.getElementById('compareBtn').addEventListener('click', () => {
  chrome.storage.local.get(['following', 'followers'], (data) => {
    if (!data.following || !data.followers) {
      const err = document.getElementById('errorMsg');
      err.textContent = 'Please scrape both pages first using the 🔍 button.';
      err.style.display = 'block';
      setTimeout(() => err.style.display = 'none', 3000);
      return;
    }
    compare(data);
  });
});

document.getElementById('clearBtn').addEventListener('click', () => {
  chrome.storage.local.remove(['following', 'followers'], () => {
    chrome.storage.local.get(['following', 'followers'], (data) => {
      updateStatus(data);
      document.getElementById('results').style.display = 'none';
    });
  });
});

function openTab(type) {
  const pageHandle = 'honeysettclinics'; // default hint — user can navigate themselves
  chrome.tabs.create({ url: `https://www.facebook.com/${pageHandle}/${type}` });
}
