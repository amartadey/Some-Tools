// background.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SCRAPED') {
    // Update badge to signal data is ready
    chrome.storage.local.get(['following', 'followers'], (data) => {
      const hasBoth = data.following && data.followers;
      chrome.action.setBadgeText({ text: hasBoth ? '✓' : '…' });
      chrome.action.setBadgeBackgroundColor({ color: hasBoth ? '#2e7d32' : '#e8a000' });
    });
  }
});
